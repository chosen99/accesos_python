import pypyodbc
pypyodbc.lowercase = False
conn = pypyodbc.connect(
    r"Driver={Microsoft Access Driver (*.mdb, *.accdb)};" +
    r"Dbq=C:\Users\atole\Desktop\DB.accdb;")
cur = conn.cursor()
try:
    cur.execute("SELECT * FROM rfid WHERE Codigo = '00065'")
    row = cur.fetchone()
    print(u"Nombre: {0}\nApellido_P: {1}\nApellido_M: {2}".format(row.get("Nombre"), row.get("A_P"), row.get("A_M")))
except:
    print("no data")
cur.close()
conn.close()
