import requests
import json
import sqlite3
# params = {'key': '2'}
# res = requests.get('http://192.168.1.76/index.php', params)
# response = json.loads(res.text)
# print(response[0]['Foto'])
# for nas in response:
#     print(nas['Foto'])

con = sqlite3.connect("caeta")
cur = con.cursor()
res = cur.execute("SELECT * FROM alumnos")
print(res.fetchall())
con.close()
